#pragma once
#include "Node.h"
#include "Rect.h"
#include <SDL.h>

class Stack
{
private:
    Node* head;     // Points to top of Stack
    Node* tail;     // Points to bottom of stack
    Node* lastDrawn; // Stores pointer to LAST DRAWN SHAPE
    int length;     // Stores length of stack which is used to give each node
                    // its unique value

public:
    Stack();        // Creates stack and sets attributes
    ~Stack();       // Empties Stack by deleting all Nodes, destroys stack
    void SendToBack();      // Moves the last drawn shape one Node deeper into the stack
    void BringToFront();    // Moves the last drawn shape one Node towards the top of stack
    void Push(Shape*);  // Creates a Node which stores passed shape and appends at top of stack
    void Push(Node*);   // Appends the incoming Node to the top of stack
    void Dump();    // Empties Stack by deleting all Nodes, does not destroy stack
    Node* Pop();    // Removes and returns the Node of last drawn shape after disconnecting it
    Node* GetLastDrawn();   // Finds the last drawn Shape using Unique value of each Node
    void Show(SDL_Renderer*);   // Draws all shapes on the screen starting from bottom of stack
    bool IsEmpty(); // Checks if the stack is empty
};
