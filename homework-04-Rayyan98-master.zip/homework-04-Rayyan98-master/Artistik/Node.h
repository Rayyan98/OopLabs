#pragma once
#include "Rect.h"

class Node
{
private:
    Shape* value;   // The value of the Node will be a pointer to a Shape object
    Node* prev;     // Stores pointer to previous Node
    Node* next;     // Stores pointer to Next Node
    int numAdded;   // Stores the number at which the Node was added in Stack
                    // This number will be unique for every Node in a stack
                    // and the last added node will always have the same unique
                    // number as the length of the stack

public:
    Node(Shape*);   // Creates Node using Shape object as value
    ~Node();        // Deletes Shape object on destruction
    void SetValue(Shape*);  // Setter functions
    void SetNumAdded(int);
    void SetNext(Node*);
    void SetPrev(Node*);
    Shape* GetValue();      // Getter functions
    int GetNumAdded();
    Node* GetNext();
    Node* GetPrev();
};
