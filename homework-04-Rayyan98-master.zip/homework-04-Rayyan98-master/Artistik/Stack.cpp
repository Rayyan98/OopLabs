#include "Stack.h"
#include <iostream>

// Initializes Stack and sets its length as 0
Stack::Stack()
{
    this->head = NULL;
    this->tail = NULL;
    this->lastDrawn = NULL;
    this->length = 0;
}

// Takes a shape pointer, assigns it to a node and adds node to top of stack
void Stack::Push(Shape* shape)
{
    Node* n = new Node(shape);      // New node created and shape assigned to it
    n->SetNumAdded(this->length);   // Gives the node a unique number for the stack using length
    if(this->head == NULL)
    {
        this->head = n;
        this->tail = n;
    }
    else
    {
        n->SetPrev(this->head);
        this->head->SetNext(n);
        this->head = n;
    }
    this->length += 1;          // Increases length of stack
    this->lastDrawn = n; // Updates lastDrawn pointer to the new added node
}

// Takes a Node pointer and adds node to top of stack
void Stack::Push(Node* newNode)
{
    if(this->head != NULL)
    {
        newNode->SetPrev(this->head);
        newNode->SetNext(NULL);
        this->head->SetNext(newNode);
        this->head = newNode;
    }
    else
    {
        this->tail = newNode;
        this->head = newNode;
        newNode->SetPrev(NULL);
        newNode->SetNext(NULL);
    }
    newNode->SetNumAdded(this->length); // Gives the node a new unique number
    this->length += 1;      // Increases length of stack
    this->lastDrawn = newNode; // Updates lastDrawn pointer to the new added node
}

// Finds and returns the Node of LAST DRAWN SHAPE from the stack using the
// unique numbers assigned to each node, iterates bottom up
Node* Stack::GetLastDrawn()
{
    Node* temp = this->tail;
    if(temp == NULL)
    {
        return temp;
    }
    while(temp->GetNumAdded() != length -1) // Node of last drawn shape will have it's
    {                                       // unique number 1 less than length of stack
        temp = temp->GetNext();
    }
    return temp;
}

// Removes and returns the Node of LAST DRAWN SHAPE from the stack after disconnecting it
Node* Stack::Pop()
{
    Node* temp = this->lastDrawn;    // Fetches node of last drawn shape
    if(temp == this->tail && head == this->tail)
    {
        this->tail = NULL;
        this->head = NULL;
        this->lastDrawn = NULL;
    }
    else if(temp == this->tail)
    {
        this->tail = temp->GetNext();
        this->tail->SetPrev(NULL);
    }
    else if(temp == this->head)
    {
        this->head = temp->GetPrev();
        this->head->SetNext(NULL);
    }
    else
    {
        temp->GetPrev()->SetNext(temp->GetNext());
        temp->GetNext()->SetPrev(temp->GetPrev());
    }
    this->length -= 1; // Decreases length of stack
    this->lastDrawn = this->GetLastDrawn(); // Updates lastDrawn pointer after finding LAST DRAWN NODE in stack
    return temp;    // returns the address of the node
}

// Iterates over the stack and draws each object on the passed surface
void Stack::Show(SDL_Renderer* surface)
{
    Node* temp = this->tail;
    while(temp != NULL)
    {
        temp->GetValue()->Draw(surface); // Draws shape
        temp = temp->GetNext();
    }
}

// Returns if the stack is empty or not, true if empty
bool Stack::IsEmpty()
{
    return this->head == NULL;
}

// Finds LAST DRAWN SHAPE and moves it deeper into the stack
void Stack::SendToBack()
{
    Node* current = this->lastDrawn; // Fetches Node of last drawn shape
    if(current != this->tail)   // Exchanges the shape pointer between the current Node and the
    {                           // node before it, also exchanges the unique value of the two nodes
        Node* tempPrev = current->GetPrev();
        Shape* ptr = tempPrev->GetValue();
        int tempa = tempPrev->GetNumAdded();
        tempPrev->SetValue(current->GetValue());
        tempPrev->SetNumAdded(current->GetNumAdded());
        current->SetValue(ptr);
        current->SetNumAdded(tempa);
        this->lastDrawn = tempPrev;
    }
}

// Finds LAST DRAWN SHAPE and brings it towards top of stack
void Stack::BringToFront()
{
    Node* current = this->lastDrawn; // Fetches Node of last drawn shape
    if(current != this->head) // Exchanges the shape pointer between the current node and the
    {                         // node after it, also exchanges the unique value of the two nodes
        Node* tempNext = current->GetNext();
        Shape* ptr = tempNext->GetValue();
        int tempa = tempNext->GetNumAdded();
        tempNext->SetValue(current->GetValue());
        tempNext->SetNumAdded(current->GetNumAdded());
        current->SetValue(ptr);
        current->SetNumAdded(tempa);
        this->lastDrawn = tempNext;
    }
}

// Deletes all the Nodes in the stack without getting rid of stack
void Stack::Dump()
{
    while(this->head != NULL)
    {
        Node* temp = this->head->GetPrev();
        delete this->head;
        this->head = temp;
    }
    this->head = NULL;
    this->tail = NULL;
    this->lastDrawn = NULL;
}

// Deletes all Nodes in stack and gets rid of stack
Stack::~Stack()
{
    this->Dump();
}

