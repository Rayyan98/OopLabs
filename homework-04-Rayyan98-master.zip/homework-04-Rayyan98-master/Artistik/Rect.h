#pragma once
#include "SDL.h"
#include "Point.h"
#include "Shape.h"

class Rect : public Shape
{
private:
    SDL_Rect fillRect;  // Stores the startPoint and dimensions of rectangle

public:
    Rect(Point, Point);     // Constructor that takes startPoint and endpoint
    void UpdateEndPoint(Point); // Adjusts the endPoint of the Rectangle as the user drags mouse when clicked
    void Draw(SDL_Renderer*);   // Draws Line on passed surface
};
