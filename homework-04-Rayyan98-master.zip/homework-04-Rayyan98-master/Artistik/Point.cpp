#include "Point.h"

// Initializes with both x and y as 0
Point::Point()
{
    this->x = 0;
    this->y = 0;
}

// Initializes with some values for x and y
Point::Point(int x, int y)
{
    this->x = x;
    this->y = y;
}

// Copies all attributes to new point
Point::Point(const Point& point)
{
    x = point.x;
    y = point.y;
}
