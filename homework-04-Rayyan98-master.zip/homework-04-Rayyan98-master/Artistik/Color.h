#pragma once

struct Color
{
    int red;    // R G B values for color
    int green;
    int blue;

    Color();    // Initializes attributes with random value
    Color(int, int, int);   // Initializes with specific values
};
