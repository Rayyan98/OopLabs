#include "Line.h"

// Serves to be able to create Line objects and calls shape constructor
Line::Line(Point startPoint, Point endPoint) : Shape(startPoint, endPoint)
{

}

// Adjusts the endPoint of the Line as the user drags mouse when clicked
void Line::UpdateEndPoint(Point endPoint)
{
    this->SetEndPoint(endPoint);
}

// Sets renderer draw color to that of the Shape and Draws the line on the passed surface
void Line::Draw(SDL_Renderer* surface)
{
    SDL_SetRenderDrawColor( surface, this->GetColor().red, this->GetColor().blue, this->GetColor().green, 255);
    SDL_RenderDrawLine(surface, this->GetStartPoint().x, this->GetStartPoint().y, this->GetEndPoint().x, this->GetEndPoint().y);
}
