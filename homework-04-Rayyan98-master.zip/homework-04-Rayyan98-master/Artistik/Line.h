#pragma once
#include "SDL.h"
#include "Point.h"
#include "Shape.h"

class Line : public Shape
{
public:
    Line(Point, Point);     // Constructor for Line that takes start and end point
    void UpdateEndPoint(Point); // Adjusts the endPoint of the Line as the user drags mouse when clicked
    void Draw(SDL_Renderer*);   // Draws the line on the passed surface
};
