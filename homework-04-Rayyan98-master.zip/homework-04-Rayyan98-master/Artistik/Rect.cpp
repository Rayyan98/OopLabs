#include "Rect.h"

// Serves to create Rectangle object and calls shape constructor
Rect::Rect(Point startPoint, Point endPoint) : Shape(startPoint, endPoint)
{

}

// Adjusts the endPoint of the Rectangle as the user drags mouse when clicked
void Rect::UpdateEndPoint(Point endPoint)
{
    fillRect = {GetStartPoint().x, GetStartPoint().y, endPoint.x - GetStartPoint().x, endPoint.y - GetStartPoint().y};
}

// Sets the Renderer Draw color and Draws rectangle on passed surface
void Rect::Draw(SDL_Renderer* gRenderer)
{
    SDL_SetRenderDrawColor( gRenderer, this->GetColor().red, this->GetColor().blue, this->GetColor().green, 255);
    SDL_RenderFillRect( gRenderer, &this->fillRect );
}
