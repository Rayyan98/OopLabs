#pragma once

struct Point
{
    int x;  // Stores x coordinate of point
    int y;  // Stores y coordinate of point

    Point();    // Initializes with both value as zero
    Point(int , int);   // Initializes point with some value for x and y
    Point(const Point&);    // Copy constructor for point
};
