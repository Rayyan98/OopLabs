#pragma once
#include "Color.h"
#include "Point.h"
#include <SDL.h>

class Shape
{
private:
    Color color;    // Stores color of shape
    Point startPoint;   // Stores startPoint of shape
    Point endPoint;     // Stores endpoint of shape

protected:
    Shape(Point, Point);    // Sets start and end pints and assign random color
    Color GetColor();   // Getter Functions
    Point GetStartPoint();
    Point GetEndPoint();
    void SetColor(Color);   // Setter Functions
    void SetStartPoint(Point);
    void SetEndPoint(Point);

public:
    virtual ~Shape();
    virtual void UpdateEndPoint(Point) = 0; // Updates the EndPoint of a shape as user drags mouse
    virtual void Draw(SDL_Renderer*) = 0;   // Draws shape on screen
};
