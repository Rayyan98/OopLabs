/*This source code copyrighted by Lazy Foo' Productions (2004-2015)
and may not be redistributed without written permission.*/

//Using SDL, SDL_image, standard IO, math, and strings
#include <SDL.h>
#include <SDL_image.h>
#include <stdio.h>
#include <string>
#include <cmath>
#include <cstdlib>
#include <ctime>
#include <iostream>
#include "Rect.h"
#include "Stack.h"
#include "Line.h"
#include "Shape.h"

//Screen dimension constants
const int SCREEN_WIDTH = 640;
const int SCREEN_HEIGHT = 480;

//Starts up SDL and creates window
bool init();

//Loads media
bool loadMedia();

//Frees media and shuts down SDL
void close();

//Loads individual image as texture
SDL_Texture* loadTexture( std::string path );

//The window we'll be rendering to
SDL_Window* gWindow = NULL;

//The window renderer
SDL_Renderer* gRenderer = NULL;

bool init()
{
	//Initialization mouseClicked
	bool success = true;

	//Initialize SDL
	if( SDL_Init( SDL_INIT_VIDEO ) < 0 )
	{
		printf( "SDL could not initialize! SDL Error: %s\n", SDL_GetError() );
		success = false;
	}
	else
	{
		//Set texture filtering to linear
		if( !SDL_SetHint( SDL_HINT_RENDER_SCALE_QUALITY, "1" ) )
		{
			printf( "Warning: Linear texture filtering not enabled!" );
		}

		//Create window
		gWindow = SDL_CreateWindow( "SDL Tutorial", SDL_WINDOWPOS_UNDEFINED, SDL_WINDOWPOS_UNDEFINED, SCREEN_WIDTH, SCREEN_HEIGHT, SDL_WINDOW_SHOWN );
		if( gWindow == NULL )
		{
			printf( "Window could not be created! SDL Error: %s\n", SDL_GetError() );
			success = false;
		}
		else
		{
			//Create renderer for window
			gRenderer = SDL_CreateRenderer( gWindow, -1, SDL_RENDERER_ACCELERATED );
			if( gRenderer == NULL )
			{
				printf( "Renderer could not be created! SDL Error: %s\n", SDL_GetError() );
				success = false;
			}
			else
			{
				//Initialize renderer color
				SDL_SetRenderDrawColor( gRenderer, 0xFF, 0xFF, 0xFF, 0xFF );

				//Initialize PNG loading
				int imgFlags = IMG_INIT_PNG;
				if( !( IMG_Init( imgFlags ) & imgFlags ) )
				{
					printf( "SDL_image could not initialize! SDL_image Error: %s\n", IMG_GetError() );
					success = false;
				}
			}
		}
	}

	return success;
}

bool loadMedia()
{
	//Loading success mouseClicked
	bool success = true;

	//Nothing to load
	return success;
}

void close()
{
	//Destroy window
	SDL_DestroyRenderer( gRenderer );
	SDL_DestroyWindow( gWindow );
	gWindow = NULL;
	gRenderer = NULL;

	//Quit SDL subsystems
	IMG_Quit();
	SDL_Quit();
}

SDL_Texture* loadTexture( std::string path )
{
	//The final texture
	SDL_Texture* newTexture = NULL;

	//Load image at specified path
	SDL_Surface* loadedSurface = IMG_Load( path.c_str() );
	if( loadedSurface == NULL )
	{
		printf( "Unable to load image %s! SDL_image Error: %s\n", path.c_str(), IMG_GetError() );
	}
	else
	{
		//Create texture from surface pixels
        newTexture = SDL_CreateTextureFromSurface( gRenderer, loadedSurface );
		if( newTexture == NULL )
		{
			printf( "Unable to create texture from %s! SDL Error: %s\n", path.c_str(), SDL_GetError() );
		}

		//Get rid of old loaded surface
		SDL_FreeSurface( loadedSurface );
	}

	return newTexture;
}

int main( int argc, char* args[] )
{
    srand(time(0));
	//Start up SDL and create window
	if( !init() )
	{
		printf( "Failed to initialize!\n" );
		return -1;
	}
    if( !loadMedia() )  //Load media
    {
        printf( "Failed to load media!\n" );
        return -1;
    }

    bool quit = false;  //Main loop controller

    SDL_Event e;        //Event handler that takes care of all events

    bool mouseClicked = false;  // Flag that detects is shape is being created
    Stack shapes;   // Stack that stores Shapes that are drawn onto the screen
    Stack undo;     // Stores Shapes that are popped from shapes stack on Undo action
    Point endPoint;     // Temporary variable that stores StartPoint of shape until it is added to stack
    Point startPoint;   // Temporary variable that stores EndPoint of shape until it is added to stack
    bool rectangleOn = true;    // Flag that checks if a rectangle needs to be drawn
    bool lineOn = false;    // Flag that check if a line needs to be drawn
    Shape* tempShape = NULL;   // Temporary pointer that stores shape until it is added to stack
    //While application is running
    while( !quit )
    {
        //Handle events on queue
        while( SDL_PollEvent( &e ) != 0 )
        {
            //User requests quit
            if( e.type == SDL_QUIT )
            {
                quit = true;
            }

            if(e.type == SDL_MOUSEBUTTONDOWN || e.type == SDL_MOUSEBUTTONUP || e.type == SDL_MOUSEMOTION)
            {
                if(e.type == SDL_MOUSEBUTTONDOWN && e.button.button == SDL_BUTTON_LEFT)
                {
                    if(mouseClicked == false)
                    {
                        if(lineOn || rectangleOn)   // Creates temporary respective shape on left click
                        {
                            mouseClicked = true;
                            SDL_GetMouseState(&startPoint.x, &startPoint.y);    // Sets start point and end
                            SDL_GetMouseState(&endPoint.x, &endPoint.y);        // Point as equal using mouse
                            if(lineOn)                                          // position at time of click down
                            {
                                tempShape = new Line(startPoint, endPoint);
                            }
                            else if(rectangleOn)
                            {
                                tempShape = new Rect(startPoint, endPoint);
                            }
                        }
                    }
                }
                if(e.type == SDL_MOUSEMOTION)
                {
                    if(mouseClicked && (lineOn || rectangleOn))
                    {
                        SDL_GetMouseState(&endPoint.x, &endPoint.y);    // If the user is clicked dragging and
                        tempShape->UpdateEndPoint(endPoint);            // shape is being created then updates
                    }                                                   // the endpoint of the shape as mouse moves
                }
                if(e.type == SDL_MOUSEBUTTONUP && e.button.button == SDL_BUTTON_LEFT)
                {
                    SDL_GetMouseState(&endPoint.x, &endPoint.y);
                    tempShape->UpdateEndPoint(endPoint);        // Sets final end Point of shape
                    if(lineOn || rectangleOn)
                    {
                        if(endPoint.x != startPoint.x || endPoint.y != startPoint.y)
                        {
                            shapes.Push(tempShape); // adds created shape to stack
                        }
                        mouseClicked = false;
                        undo.Dump();        // Empties the Undo stack when new shape is created
                        tempShape = NULL;
                    }
                }
                if(!mouseClicked && e.type == SDL_MOUSEBUTTONDOWN)
                {
                    if(e.button.button == SDL_BUTTON_RIGHT)
                    {
                        if(!shapes.IsEmpty())   // Pops LAST DRAWN SHAPE from shape stack and
                        {                       // adds to the undo stack
                            undo.Push(shapes.Pop());
                        }
                    }
                    else if(e.button.button == SDL_BUTTON_MIDDLE)
                    {
                        if(!undo.IsEmpty())     // Pops last Undo-ed shape from undo stack and
                        {                       // adds it back to main shape stack
                            shapes.Push(undo.Pop());
                        }
                    }
                }
            }
            if(e.type == SDL_KEYDOWN && !mouseClicked)
            {
                if(e.key.keysym.sym == SDLK_l)  // Switches to drawing Lines
                {
                    rectangleOn = false;
                    lineOn = true;
                }
                else if(e.key.keysym.sym == SDLK_r) // Switches to drawing rectangles
                {
                    rectangleOn = true;
                    lineOn = false;
                }
                else if(e.key.keysym.sym == SDLK_KP_PLUS)   // Sends LAST DRAWN SHAPE one node towards top of stack
                {
                    if(!shapes.IsEmpty())
                    {
                        shapes.BringToFront();
                    }
                }
                else if(e.key.keysym.sym == SDLK_KP_MINUS)  // Sends LAST DRAWN SHAPE one node deeper into the stack
                {
                    if(!shapes.IsEmpty())
                    {
                        shapes.SendToBack();
                    }
                }
            }
        }
        //Clear screen

        SDL_SetRenderDrawColor( gRenderer, 255, 255, 255, 255 );
        SDL_RenderClear( gRenderer );

        if (!shapes.IsEmpty())
        {
            shapes.Show(gRenderer); // Draws all Shapes in stack bottom up
        }
        if(tempShape != NULL)
        {
            tempShape->Draw(gRenderer);
        }

        //Update screen
        SDL_RenderPresent( gRenderer );
    }


	//Free resources and close SDL

	close();

	return 0;
}
