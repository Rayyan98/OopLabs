#include "Color.h"

// Initializes color as white
Color::Color()
{
    red = 255;
    green = 255;
    blue = 255;
}

// Initializes with some value between 0 and 255
Color::Color(int red, int green, int blue)
{
    this->red = red;
    this->green = green;
    this->blue = blue;
}
