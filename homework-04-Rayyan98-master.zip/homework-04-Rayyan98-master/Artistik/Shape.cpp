#include <iostream>
#include "Shape.h"
#include <cstdlib>

// Assign start point, end point, and random color to shape
Shape::Shape(Point startPoint, Point endPoint)
{
    this->color.red = rand()%256;
    this->color.blue = rand()%256;
    this->color.green = rand()%256;
    this->startPoint = startPoint;
    this->endPoint = endPoint;
}

Shape::~Shape()
{

}

// Getter Functions
Color Shape::GetColor()
{
    return this->color;
}

Point Shape::GetStartPoint()
{
    return this->startPoint;
}

Point Shape::GetEndPoint()
{
    return this->endPoint;
}

// Setter Functions
void Shape::SetColor(Color color)
{
    this->color = color;
}

void Shape::SetStartPoint(Point startPoint)
{
    this->startPoint = startPoint;
}

void Shape::SetEndPoint(Point endPoint)
{
    this->endPoint = endPoint;
}
