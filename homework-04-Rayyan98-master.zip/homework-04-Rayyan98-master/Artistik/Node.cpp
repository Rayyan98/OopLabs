#include "Node.h"
#include <iostream>

// Creates Node with Shape as value and sets other attributes
Node::Node(Shape* shapePtr)
{
    this->value = shapePtr;
    this->prev = NULL;
    this->next = NULL;
    this->numAdded = 0;
}

// Deletes the shape on destruction of Node
Node::~Node()
{
    delete this->value;
}

// Setter Functions
void Node::SetValue(Shape* shape)
{
    this->value = shape;
}

void Node::SetNumAdded(int numAdded)
{
    this->numAdded = numAdded;
}

void Node::SetNext(Node* next)
{
    this->next = next;
}

void Node::SetPrev(Node* prev)
{
    this->prev = prev;
}

// Getter Functions
Shape* Node::GetValue()
{
    return this->value;
}

int Node::GetNumAdded()
{
    return this->numAdded;
}

Node* Node::GetNext()
{
    return this->next;
}

Node* Node::GetPrev()
{
    return this->prev;
}
